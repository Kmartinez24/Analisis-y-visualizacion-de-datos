package calcfloats

func Suma(n1, n2 float32) float32 {
	//Suma ambos valores
	return n1 + n2
}

func Resta(n1, n2 float32) float32 {
	//Le restas el segundo valor al primero
	return n1 - n2
}

func Resta2(n1, n2 float32) float32 {
	//Le restas el primer valor al segundo
	return n2 - n1
}

func Multiplicacion(n1, n2 float32) float32 {
	//Multiplicacion
	return n1 * n2
}

func Division(n1, n2 float32) float32 {
	//Division
	return n1 / n2
}
