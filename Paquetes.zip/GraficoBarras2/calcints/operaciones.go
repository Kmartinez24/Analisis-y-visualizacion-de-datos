package calcints

func Suma(n1, n2 int) int {
	//Suma ambos valores
	return n1 + n2
}

func Resta(n1, n2 int) int {
	//Le restas el segundo valor al primero
	return n1 - n2
}

func Resta2(n1, n2 int) int {
	//Le restas el primer valor al segundo
	return n2 - n1
}

func Multiplicacion(n1, n2 int) int {
	// Multiplicacion
	return n1 * n2
}

func Division(n1, n2 int) int {
	//Division entera
	return n1 / n2
}
